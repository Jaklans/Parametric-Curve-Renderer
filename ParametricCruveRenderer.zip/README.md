# Parametric Curve Ray Tracer
A Vulkan based renderer designed to show geometry described via parametric curves using a ray tracing algorithim
