#pragma once

#define WIDTH 970
#define HEIGHT 540

//#define WIDTH 2560
//#define HEIGHT 1440

#define WORKGROUP_SIZE 32